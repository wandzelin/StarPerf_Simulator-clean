name = 'global-land-mask'

from .globe import *