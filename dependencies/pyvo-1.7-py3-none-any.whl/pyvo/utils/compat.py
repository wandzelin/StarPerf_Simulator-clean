# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
Placeholder for compatibility constructs
"""

__all__ = []
